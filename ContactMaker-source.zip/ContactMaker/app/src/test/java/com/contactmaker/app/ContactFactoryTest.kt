package com.contactmaker.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.StringWriter

class ContactFactoryTest {
    @Test
    fun generatesOneThousandUniqueContacts() {
        val contacts = ContactFactory.generate(group = 6, count = 1_000, start = 1)
        assertEquals(1_000, contacts.size)
        assertEquals("فعال6_1", contacts.first().displayName)
        assertEquals("فعال6_1000", contacts.last().displayName)
        assertEquals(1_000, contacts.map { it.phoneNumber }.toSet().size)
    }

    @Test
    fun generatesTenThousandUniqueContacts() {
        val contacts = ContactFactory.generate(group = 7, count = 10_000, start = 50)
        assertEquals(10_000, contacts.size)
        assertEquals("فعال7_50", contacts.first().displayName)
        assertEquals("فعال7_10049", contacts.last().displayName)
        assertEquals(10_000, contacts.map { it.phoneNumber }.toSet().size)
        assertTrue(contacts.all { it.phoneNumber.startsWith("TEST-") })
    }

    @Test
    fun differentGroupsProduceDifferentSyntheticNumbers() {
        val a = ContactFactory.generate(group = 6, count = 1, start = 1).single()
        val b = ContactFactory.generate(group = 7, count = 1, start = 1).single()
        assertNotEquals(a.phoneNumber, b.phoneNumber)
    }

    @Test
    fun vcardWriterEscapesSpecialCharacters() {
        val writer = StringWriter()
        VCardWriter.write(listOf(ContactRecord("فعال;1", "TEST,1")), writer)
        assertTrue(writer.toString().contains("FN:فعال\\;1\r\n"))
        assertTrue(writer.toString().contains("TEL;TYPE=OTHER:TEST\\,1\r\n"))
    }
}
