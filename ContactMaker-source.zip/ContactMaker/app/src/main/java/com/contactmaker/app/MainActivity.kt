package com.contactmaker.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentProviderOperation
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.ContactsContract
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.text.Editable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.CancellationException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class MainActivity : Activity() {
    private enum class Operation { IDLE, GENERATING, REGISTERING, EXPORTING }
    private data class Request(val group: Long, val count: Int, val start: Long)

    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val cancelRequested = AtomicBoolean(false)

    private lateinit var groupInput: EditText
    private lateinit var countInput: EditText
    private lateinit var startInput: EditText
    private lateinit var previewText: TextView
    private lateinit var statusText: TextView
    private lateinit var progressText: TextView
    private lateinit var reportText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var previewButton: Button
    private lateinit var generateButton: Button
    private lateinit var registerButton: Button
    private lateinit var exportButton: Button
    private lateinit var stopButton: Button

    @Volatile private var operation = Operation.IDLE
    private var generatedContacts: List<ContactRecord> = emptyList()
    private var generatedGroup: Long? = null

    companion object {
        private const val REQUEST_CONTACT_PERMISSIONS = 4101
        private const val REQUEST_CREATE_VCF = 4102
        private const val BATCH_CONTACT_COUNT = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(20, 43, 74)
        window.navigationBarColor = Color.rgb(20, 43, 74)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.rgb(245, 247, 251))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(18), dp(18), dp(28))
        }
        scroll.addView(content, ScrollView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = rounded(Color.rgb(20, 43, 74), 20)
        }
        hero.addView(label("ContactMaker", 25f, Color.WHITE, true))
        hero.addView(label("تولید و ثبت مخاطبین آزمایشی در گوشی", 14f, Color.rgb(219, 230, 245), false).apply {
            setPadding(0, dp(7), 0, 0)
        })
        content.addView(hero, matchWrap().withBottom(dp(16)))

        val inputCard = card()
        inputCard.addView(label("اطلاعات تولید", 18f, Color.rgb(25, 43, 68), true))
        groupInput = addInput(inputCard, "شماره گروه", "مثلاً 6")
        countInput = addInput(inputCard, "تعداد مخاطبین (حداکثر ۱۰۰۰۰)", "مثلاً 1000")
        startInput = addInput(inputCard, "شماره شروع", "مثلاً 1")
        content.addView(inputCard, matchWrap().withBottom(dp(14)))

        val previewCard = card()
        previewCard.addView(label("پیش‌نمایش", 17f, Color.rgb(25, 43, 68), true))
        previewText = label("پس از وارد کردن اطلاعات، پیش‌نمایش را بزنید.", 14f, Color.rgb(75, 89, 108), false).apply {
            setPadding(0, dp(10), 0, 0)
            gravity = Gravity.END
            textDirection = View.TEXT_DIRECTION_RTL
        }
        previewCard.addView(previewText)
        content.addView(previewCard, matchWrap().withBottom(dp(14)))

        previewButton = actionButton("۱. پیش‌نمایش", Color.rgb(234, 241, 255), Color.rgb(32, 78, 155)) {
            showPreview()
        }
        content.addView(previewButton, matchWrap().withBottom(dp(9)))

        generateButton = actionButton("۲. تولید مخاطبین", Color.rgb(37, 99, 235), Color.WHITE) {
            confirmGeneration()
        }
        content.addView(generateButton, matchWrap().withBottom(dp(9)))

        registerButton = actionButton("۳. ثبت مخاطبین در گوشی", Color.rgb(22, 133, 91), Color.WHITE) {
            requestContactAccess()
        }
        content.addView(registerButton, matchWrap().withBottom(dp(9)))

        exportButton = actionButton("۴. خروجی فایل VCF", Color.rgb(234, 241, 255), Color.rgb(32, 78, 155)) {
            chooseVcfDestination()
        }
        content.addView(exportButton, matchWrap().withBottom(dp(9)))

        stopButton = actionButton("توقف عملیات", Color.rgb(254, 235, 235), Color.rgb(173, 48, 48)) {
            cancelRequested.set(true)
            statusText.text = "درخواست توقف ثبت شد؛ پس از پایان بخش جاری متوقف می‌شود."
        }.apply { visibility = View.GONE }
        content.addView(stopButton, matchWrap().withBottom(dp(14)))

        val statusCard = card()
        statusCard.addView(label("وضعیت عملیات", 17f, Color.rgb(25, 43, 68), true))
        statusText = label("آماده انجام عملیات", 14f, Color.rgb(75, 89, 108), false).apply {
            setPadding(0, dp(10), 0, dp(8))
        }
        statusCard.addView(statusText)
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(37, 99, 235))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(226, 233, 243))
        }
        statusCard.addView(progressBar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(9)
        ))
        progressText = label("۰٪", 12f, Color.rgb(91, 105, 124), false).apply {
            setPadding(0, dp(7), 0, dp(10))
        }
        statusCard.addView(progressText)
        reportText = label("گزارش نهایی پس از ثبت نمایش داده می‌شود.", 13f, Color.rgb(75, 89, 108), false).apply {
            setPadding(0, dp(4), 0, 0)
        }
        statusCard.addView(reportText)
        content.addView(statusCard, matchWrap())

        addInputWatchers()
        updateActionAvailability()
        setContentView(scroll)
    }

    private fun addInput(parent: LinearLayout, caption: String, hint: String): EditText {
        parent.addView(label(caption, 14f, Color.rgb(58, 72, 92), true).apply {
            setPadding(0, dp(15), 0, dp(6))
        })
        return EditText(this).apply {
            this.hint = hint
            inputType = InputType.TYPE_CLASS_NUMBER
            textSize = 16f
            setTextColor(Color.rgb(25, 43, 68))
            setHintTextColor(Color.rgb(147, 158, 174))
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            textDirection = View.TEXT_DIRECTION_LOCALE
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            isSingleLine = true
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = resources.getDrawable(com.contactmaker.app.R.drawable.input_background, theme)
            filters = arrayOf(InputFilter.LengthFilter(15))
            parent.addView(this, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50)
            ))
        }
    }

    private fun addInputWatchers() {
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (operation == Operation.IDLE && generatedContacts.isNotEmpty()) {
                    generatedContacts = emptyList()
                    generatedGroup = null
                    reportText.text = "ورودی‌ها تغییر کردند؛ برای ثبت یا خروجی، دوباره مخاطبین را تولید کنید."
                    updateActionAvailability()
                }
            }
            override fun afterTextChanged(s: Editable?) = Unit
        }
        groupInput.addTextChangedListener(watcher)
        countInput.addTextChangedListener(watcher)
        startInput.addTextChangedListener(watcher)
    }

    private fun showPreview() {
        val request = readRequest() ?: return
        val samples = ContactFactory.generate(
            group = request.group,
            count = minOf(request.count, 5),
            start = request.start
        )
        val lines = buildString {
            append("گروه: ${request.group}\nتعداد: ${request.count}\nشروع از: ${request.start}\n\nنمونه مخاطبین:\n")
            samples.forEach { append("• ${it.displayName}\n  ${it.phoneNumber}\n") }
            if (request.count > samples.size) append("… و ${request.count - samples.size} مخاطب دیگر")
            append("\n\nشماره‌ها آزمایشی هستند و برای تماس واقعی طراحی نشده‌اند.")
        }
        previewText.text = lines
        statusText.text = "پیش‌نمایش آماده است؛ برای ساخت فهرست، دکمه تولید را بزنید."
        reportText.text = "هنوز هیچ مخاطبی در دفترچه تلفن ثبت نشده است."
    }

    private fun confirmGeneration() {
        val request = readRequest() ?: return
        val message = "تعداد ${request.count} مخاطب با نام فعال${request.group}_${request.start} به بعد ساخته می‌شود.\n\nاین مرحله فقط داده‌ها را در حافظه برنامه تولید می‌کند و هنوز چیزی در دفترچه تلفن ثبت نمی‌شود. ادامه می‌دهید؟"
        AlertDialog.Builder(this)
            .setTitle("تأیید تولید مخاطبین")
            .setMessage(message)
            .setNegativeButton("بازگشت", null)
            .setPositiveButton("تولید") { _, _ -> startGeneration(request) }
            .show()
    }

    private fun startGeneration(request: Request) {
        cancelRequested.set(false)
        operation = Operation.GENERATING
        setBusy(true)
        progressBar.progress = 0
        progressText.text = "۰٪"
        reportText.text = "در حال ساخت فهرست در حافظه برنامه…"
        statusText.text = "در حال تولید مخاطبین"
        val started = SystemClock.elapsedRealtime()

        executor.execute {
            try {
                val records = ContactFactory.generate(
                    group = request.group,
                    count = request.count,
                    start = request.start,
                    shouldCancel = { cancelRequested.get() },
                    onProgress = { completed ->
                        mainHandler.post {
                            if (operation == Operation.GENERATING) {
                                val percent = completed * 100 / request.count
                                progressBar.progress = percent
                                progressText.text = "$completed از ${request.count}  •  $percent٪"
                            }
                        }
                    }
                )
                val elapsed = SystemClock.elapsedRealtime() - started
                mainHandler.post {
                    generatedContacts = records
                    generatedGroup = request.group
                    operation = Operation.IDLE
                    setBusy(false)
                    progressBar.progress = 100
                    progressText.text = "۱۰۰٪"
                    statusText.text = "تولید مخاطبین با موفقیت انجام شد."
                    reportText.text = "تعداد تولیدشده: ${records.size}\nمدت تولید: ${formatDuration(elapsed)}\nبرای ثبت مستقیم یا ساخت فایل VCF یکی از دکمه‌ها را انتخاب کنید."
                    updateActionAvailability()
                }
            } catch (_: CancellationException) {
                mainHandler.post {
                    operation = Operation.IDLE
                    setBusy(false)
                    statusText.text = "تولید توسط کاربر متوقف شد؛ فهرست ناقص نگه‌داری نشد."
                    reportText.text = "هیچ مخاطبی برای ثبت آماده نیست."
                    progressBar.progress = 0
                    progressText.text = "۰٪"
                    updateActionAvailability()
                }
            } catch (error: Exception) {
                mainHandler.post {
                    operation = Operation.IDLE
                    setBusy(false)
                    statusText.text = "خطا در تولید مخاطبین"
                    reportText.text = error.message ?: "خطای ناشناخته رخ داد."
                    updateActionAvailability()
                }
            }
        }
    }

    private fun requestContactAccess() {
        if (generatedContacts.isEmpty()) {
            showToast("ابتدا مخاطبین را تولید کنید.")
            return
        }
        val required = arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS)
        val missing = required.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), REQUEST_CONTACT_PERMISSIONS)
        } else {
            showRegistrationConfirmation()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CONTACT_PERMISSIONS) {
            val readGranted = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
            val writeGranted = checkSelfPermission(Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED
            if (readGranted && writeGranted) {
                showRegistrationConfirmation()
            } else {
                showToast("برای بررسی تکراری‌ها و ثبت مخاطبین، مجوز خواندن و نوشتن مخاطبین لازم است.")
                statusText.text = "مجوز مخاطبین داده نشد؛ هیچ تغییری در دفترچه تلفن انجام نشد."
            }
        }
    }

    private fun showRegistrationConfirmation() {
        val count = generatedContacts.size
        AlertDialog.Builder(this)
            .setTitle("تأیید نهایی ثبت در گوشی")
            .setMessage("قرار است حداکثر $count مخاطب مستقیماً در دفترچه تلفن اندروید ثبت شود.\n\nشماره‌های آزمایشی با TEST شروع می‌شوند. مخاطبین موجود حذف یا ویرایش نمی‌شوند و شماره‌های تکراری از این عملیات رد خواهند شد. ادامه می‌دهید؟")
            .setNegativeButton("لغو", null)
            .setPositiveButton("ثبت مخاطبین") { _, _ -> startRegistration() }
            .show()
    }

    private fun startRegistration() {
        val contacts = generatedContacts.toList()
        if (contacts.isEmpty()) return
        cancelRequested.set(false)
        operation = Operation.REGISTERING
        setBusy(true)
        progressBar.progress = 0
        progressText.text = "۰٪"
        statusText.text = "در حال ثبت مخاطبین در دفترچه تلفن گوشی"
        reportText.text = "در حال بررسی شماره‌های موجود و ثبت گروهی…"
        val started = SystemClock.elapsedRealtime()

        executor.execute {
            var inserted = 0
            var duplicates = 0
            var failed = 0
            var processed = 0
            var cancelled = false
            try {
                val existingNumbers = queryExistingPhoneNumbers()
                val chunks = contacts.chunked(BATCH_CONTACT_COUNT)

                for (chunk in chunks) {
                    if (cancelRequested.get()) {
                        cancelled = true
                        break
                    }

                    val fresh = ArrayList<ContactRecord>(chunk.size)
                    var duplicateInChunk = 0
                    chunk.forEach { contact ->
                        if (existingNumbers.add(contact.phoneNumber)) fresh.add(contact) else {
                            duplicates++
                            duplicateInChunk++
                        }
                    }
                    processed += duplicateInChunk

                    if (fresh.isNotEmpty()) {
                        try {
                            val operations = ArrayList<ContentProviderOperation>(fresh.size * 3)
                            fresh.forEach { appendContactOperations(operations, it) }
                            contentResolver.applyBatch(ContactsContract.AUTHORITY, operations)
                            inserted += fresh.size
                            processed += fresh.size
                        } catch (_: Exception) {
                            // A provider/device may reject a large transaction. Retry each contact
                            // separately so one bad record does not discard the whole chunk.
                            for (contact in fresh) {
                                if (cancelRequested.get()) {
                                    cancelled = true
                                    break
                                }
                                try {
                                    val single = ArrayList<ContentProviderOperation>(3)
                                    appendContactOperations(single, contact)
                                    contentResolver.applyBatch(ContactsContract.AUTHORITY, single)
                                    inserted++
                                } catch (_: Exception) {
                                    failed++
                                }
                                processed++
                            }
                        }
                    }

                    if (chunk.isEmpty()) continue
                    val completed = processed
                    val elapsed = SystemClock.elapsedRealtime() - started
                    val eta = if (completed > 0) (elapsed.toDouble() * (contacts.size - completed).coerceAtLeast(0) / completed).toLong() else 0L
                    mainHandler.post {
                        if (operation == Operation.REGISTERING) {
                            val percent = (completed * 100 / contacts.size).coerceIn(0, 100)
                            progressBar.progress = percent
                            progressText.text = "$completed از ${contacts.size}  •  $percent٪  •  باقی‌مانده تقریبی: ${formatDuration(eta)}"
                        }
                    }
                    if (cancelled) break
                }

                val elapsed = SystemClock.elapsedRealtime() - started
                val notSuccessful = (contacts.size - inserted - duplicates).coerceAtLeast(0)
                failed = max(failed, notSuccessful)
                val wasCancelled = cancelled || cancelRequested.get()
                mainHandler.post {
                    operation = Operation.IDLE
                    setBusy(false)
                    progressBar.progress = if (wasCancelled) (processed * 100 / contacts.size).coerceIn(0, 100) else 100
                    progressText.text = "${progressBar.progress}٪"
                    statusText.text = if (wasCancelled) "عملیات ثبت متوقف شد؛ گزارش بخش انجام‌شده در زیر آمده است." else "عملیات ثبت به پایان رسید."
                    reportText.text = buildString {
                        append("تعداد درخواستی: ${contacts.size}\n")
                        append("تعداد تولیدشده: ${contacts.size}\n")
                        append("ثبت موفق: $inserted\n")
                        append("ناموفق یا پردازش‌نشده: $failed\n")
                        append("تکراری و ردشده: $duplicates\n")
                        append("مدت عملیات: ${formatDuration(elapsed)}")
                        if (wasCancelled) append("\nوضعیت: متوقف‌شده توسط کاربر")
                    }
                    updateActionAvailability()
                }
            } catch (security: SecurityException) {
                mainHandler.post {
                    operation = Operation.IDLE
                    setBusy(false)
                    statusText.text = "دسترسی به دفترچه تلفن مجاز نیست."
                    reportText.text = security.message ?: "مجوز خواندن/نوشتن مخاطبین را از تنظیمات برنامه بررسی کنید."
                    updateActionAvailability()
                }
            } catch (error: Exception) {
                mainHandler.post {
                    operation = Operation.IDLE
                    setBusy(false)
                    statusText.text = "خطا هنگام ثبت مخاطبین"
                    val failedOrPending = (contacts.size - inserted - duplicates).coerceAtLeast(0)
                    reportText.text = "تعداد درخواستی: ${contacts.size}\nثبت موفق تا پیش از خطا: $inserted\nناموفق یا پردازش‌نشده: $failedOrPending\nتکراری: $duplicates\nخطا: ${error.message ?: "نامشخص"}"
                    updateActionAvailability()
                }
            }
        }
    }

    private fun queryExistingPhoneNumbers(): MutableSet<String> {
        val numbers = HashSet<String>()
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER)
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            null,
            null,
            null
        )?.use { cursor ->
            val index = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            if (index >= 0) {
                while (cursor.moveToNext()) {
                    cursor.getString(index)?.takeIf { it.isNotBlank() }?.let(numbers::add)
                }
            }
        }
        return numbers
    }

    private fun appendContactOperations(
        operations: MutableList<ContentProviderOperation>,
        contact: ContactRecord
    ) {
        val rawContactOperationIndex = operations.size
        operations += ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
            .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
            .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
            .withYieldAllowed(true)
            .build()

        operations += ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, rawContactOperationIndex)
            .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
            .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, contact.displayName)
            .withValue(ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME, contact.displayName)
            .build()

        operations += ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, rawContactOperationIndex)
            .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
            .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, contact.phoneNumber)
            .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_CUSTOM)
            .withValue(ContactsContract.CommonDataKinds.Phone.LABEL, "شماره آزمایشی")
            .build()
    }

    private fun chooseVcfDestination() {
        if (generatedContacts.isEmpty()) {
            showToast("ابتدا مخاطبین را تولید کنید.")
            return
        }
        val group = generatedGroup ?: 0L
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/vcard"
            putExtra(Intent.EXTRA_TITLE, "ContactMaker_Group${group}.vcf")
        }
        try {
            startActivityForResult(intent, REQUEST_CREATE_VCF)
        } catch (_: Exception) {
            showToast("برنامه‌ای برای انتخاب محل ذخیره فایل در دسترس نیست.")
        }
    }

    @Deprecated("Deprecated by Android, retained for compatibility with the platform-only project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CREATE_VCF && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            exportVcf(uri)
        }
    }

    private fun exportVcf(uri: Uri) {
        val contacts = generatedContacts.toList()
        if (contacts.isEmpty()) return
        operation = Operation.EXPORTING
        setBusy(true)
        statusText.text = "در حال ساخت فایل VCF"
        reportText.text = "در حال نوشتن ${contacts.size} مخاطب در فایل…"
        executor.execute {
            try {
                val output = contentResolver.openOutputStream(uri, "wt")
                    ?: throw IllegalStateException("فایل برای نوشتن باز نشد.")
                output.bufferedWriter(Charsets.UTF_8).use { writer ->
                    VCardWriter.write(contacts, writer)
                }
                mainHandler.post {
                    operation = Operation.IDLE
                    setBusy(false)
                    statusText.text = "فایل VCF با موفقیت ساخته شد."
                    reportText.text = "تعداد مخاطبین در فایل: ${contacts.size}\nفایل در محل انتخاب‌شده ذخیره شد."
                    progressBar.progress = 100
                    progressText.text = "۱۰۰٪"
                    updateActionAvailability()
                }
            } catch (error: Exception) {
                mainHandler.post {
                    operation = Operation.IDLE
                    setBusy(false)
                    statusText.text = "ساخت فایل VCF ناموفق بود."
                    reportText.text = error.message ?: "خطای نوشتن فایل رخ داد."
                    updateActionAvailability()
                }
            }
        }
    }

    private fun readRequest(): Request? {
        val group = parseNumber(groupInput.text.toString())
        val countLong = parseNumber(countInput.text.toString())
        val start = parseNumber(startInput.text.toString())
        if (group == null || countLong == null || start == null) {
            showToast("هر سه فیلد را با عدد معتبر تکمیل کنید.")
            return null
        }
        if (group !in 1L..999_999_999L) {
            showToast("شماره گروه باید بین ۱ تا ۹۹۹۹۹۹۹۹۹ باشد.")
            return null
        }
        if (countLong !in 1L..ContactFactory.MAX_CONTACTS_PER_RUN.toLong()) {
            showToast("تعداد مخاطبین باید بین ۱ تا ۱۰۰۰۰ باشد.")
            return null
        }
        if (start < 1L || start > Long.MAX_VALUE - (countLong - 1L)) {
            showToast("شماره شروع یا بازه شماره‌گذاری معتبر نیست.")
            return null
        }
        return Request(group, countLong.toInt(), start)
    }

    private fun parseNumber(raw: String): Long? {
        val normalized = buildString {
            raw.trim().forEach { char ->
                append(
                    when (char) {
                        in '۰'..'۹' -> ('0'.code + (char.code - '۰'.code)).toChar()
                        in '٠'..'٩' -> ('0'.code + (char.code - '٠'.code)).toChar()
                        else -> char
                    }
                )
            }
        }
        if (normalized.isBlank() || normalized.any { !it.isDigit() }) return null
        return normalized.toLongOrNull()
    }

    private fun setBusy(busy: Boolean) {
        groupInput.isEnabled = !busy
        countInput.isEnabled = !busy
        startInput.isEnabled = !busy
        previewButton.isEnabled = !busy
        generateButton.isEnabled = !busy
        registerButton.isEnabled = !busy && generatedContacts.isNotEmpty()
        exportButton.isEnabled = !busy && generatedContacts.isNotEmpty()
        stopButton.visibility = if (busy && (operation == Operation.GENERATING || operation == Operation.REGISTERING)) View.VISIBLE else View.GONE
        stopButton.isEnabled = busy && (operation == Operation.GENERATING || operation == Operation.REGISTERING)
        val alpha = if (busy) 0.55f else 1f
        previewButton.alpha = alpha
        generateButton.alpha = alpha
        registerButton.alpha = if (registerButton.isEnabled) 1f else 0.55f
        exportButton.alpha = if (exportButton.isEnabled) 1f else 0.55f
    }

    private fun updateActionAvailability() {
        val idle = operation == Operation.IDLE
        registerButton.isEnabled = idle && generatedContacts.isNotEmpty()
        exportButton.isEnabled = idle && generatedContacts.isNotEmpty()
        registerButton.alpha = if (registerButton.isEnabled) 1f else 0.55f
        exportButton.alpha = if (exportButton.isEnabled) 1f else 0.55f
    }

    private fun formatDuration(milliseconds: Long): String {
        val seconds = (milliseconds / 1000L).coerceAtLeast(0)
        val minutes = seconds / 60
        val remainingSeconds = seconds % 60
        return if (minutes > 0) "$minutes دقیقه و $remainingSeconds ثانیه" else "$remainingSeconds ثانیه"
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        gravity = Gravity.END
        setPadding(dp(17), dp(17), dp(17), dp(17))
        background = resources.getDrawable(com.contactmaker.app.R.drawable.card_background, theme)
        elevation = dp(1).toFloat()
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        gravity = Gravity.END
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        textDirection = View.TEXT_DIRECTION_LOCALE
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        setLineSpacing(dp(2).toFloat(), 1f)
    }

    private fun actionButton(text: String, backgroundColor: Int, textColor: Int, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 15f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(textColor)
        background = rounded(backgroundColor, 14)
        gravity = Gravity.CENTER
        minHeight = dp(52)
        setPadding(dp(14), dp(9), dp(14), dp(9))
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun matchWrap(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun LinearLayout.LayoutParams.withBottom(margin: Int): LinearLayout.LayoutParams = apply {
        bottomMargin = margin
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        cancelRequested.set(true)
        executor.shutdownNow()
        super.onDestroy()
    }
}
