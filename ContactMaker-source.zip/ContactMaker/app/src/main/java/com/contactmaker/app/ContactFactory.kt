package com.contactmaker.app

import java.util.concurrent.CancellationException

/** A synthetic contact generated locally by ContactMaker. */
data class ContactRecord(
    val displayName: String,
    val phoneNumber: String
)

/** Pure Kotlin generator, kept independent from Android APIs so it can be unit-tested. */
object ContactFactory {
    const val MAX_CONTACTS_PER_RUN = 10_000

    fun generate(
        group: Long,
        count: Int,
        start: Long,
        shouldCancel: () -> Boolean = { false },
        onProgress: (Int) -> Unit = {}
    ): List<ContactRecord> {
        require(group in 1L..999_999_999L) { "شماره گروه باید بین ۱ تا ۹۹۹۹۹۹۹۹۹ باشد." }
        require(count in 1..MAX_CONTACTS_PER_RUN) { "تعداد باید بین ۱ تا ۱۰۰۰۰ باشد." }
        require(start >= 1L) { "شماره شروع باید حداقل ۱ باشد." }
        require(start <= Long.MAX_VALUE - (count - 1L)) { "بازه شماره‌گذاری بیش از حد بزرگ است." }

        val result = ArrayList<ContactRecord>(count)
        for (index in 0 until count) {
            if (shouldCancel()) throw CancellationException("عملیات توسط کاربر متوقف شد.")
            val sequence = start + index
            result += ContactRecord(
                displayName = "فعال${group}_$sequence",
                phoneNumber = "TEST-G${group}-${sequence.toString().padStart(8, '0')}"
            )
            if ((index + 1) % 100 == 0 || index + 1 == count) onProgress(index + 1)
        }
        return result
    }
}
