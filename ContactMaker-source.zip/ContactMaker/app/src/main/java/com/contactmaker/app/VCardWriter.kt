package com.contactmaker.app

import java.io.Writer

/** Writes vCard 3.0 records using CRLF line endings. */
object VCardWriter {
    fun write(contacts: List<ContactRecord>, writer: Writer) {
        contacts.forEach { contact ->
            writer.append("BEGIN:VCARD\r\n")
            writer.append("VERSION:3.0\r\n")
            writer.append("N:;").append(escape(contact.displayName)).append(";;;\r\n")
            writer.append("FN:").append(escape(contact.displayName)).append("\r\n")
            writer.append("TEL;TYPE=OTHER:").append(escape(contact.phoneNumber)).append("\r\n")
            writer.append("END:VCARD\r\n")
        }
        writer.flush()
    }

    private fun escape(value: String): String = value
        .replace("\\", "\\\\")
        .replace("\r\n", "\\n")
        .replace("\n", "\\n")
        .replace("\r", "\\n")
        .replace(";", "\\;")
        .replace(",", "\\,")
}
